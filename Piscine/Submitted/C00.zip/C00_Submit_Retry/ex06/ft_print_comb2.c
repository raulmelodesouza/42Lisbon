/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmelo-de <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/12 13:05:08 by rmelo-de          #+#    #+#             */
/*   Updated: 2021/01/12 13:06:12 by rmelo-de         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_display(char a, char b)
{
	ft_putchar((char)a / 10 + '0');
	ft_putchar((char)a % 10 + '0');
	ft_putchar(' ');
	ft_putchar((char)b / 10 + '0');
	ft_putchar((char)b % 10 + '0');
}

void	ft_condition(int a, int b)
{
	if (!(a == 98 && b == 99))
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

void	ft_print_comb2(void)
{
	int a;
	int b;

	a = 0;
	b = 1;
	while (a <= 98)
	{
		while (b <= 99)
		{
			ft_display(a, b);
			ft_condition(a, b);
			b++;
		}
		a++;
		b = a + 1;
	}
}
