/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmelo-de <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/19 20:28:17 by rmelo-de          #+#    #+#             */
/*   Updated: 2021/01/20 13:48:15 by rmelo-de         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		factorial(int nb, int new_nb, int i)
{
	if (i > nb)
	{
		return (new_nb);
	}
	new_nb *= i;
	i++;
	return (factorial(nb, new_nb, i));
}

int		ft_recursive_factorial(int nb)
{
	int new_nb;

	if (nb < 0)
	{
		return (0);
	}
	new_nb = 1;
	return (factorial(nb, new_nb, 1));
}
