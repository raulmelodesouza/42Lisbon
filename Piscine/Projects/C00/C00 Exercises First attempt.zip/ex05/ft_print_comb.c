/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmelo-de <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/09 20:04:40 by rmelo-de          #+#    #+#             */
/*   Updated: 2021/01/11 15:23:17 by rmelo-de         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);
void	ft_print_comb(void);

int		main(void)
{
	ft_print_comb();
	return (0);
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_comb(void)
{
	char a;
	char b;
	char c;

	a = '0';
	b = '1';
	c = '2';
	while (a <= '7')
	{
		while (b <= '8')
		{
			while (c <= '9')
			{
				if (a != b && a != c && b != c)
				{
					ft_putchar(a);
					ft_putchar(b);
                    ft_putchar(c);
                    if (a != '7' || b != '8' || c != '9')
                    {
						ft_putchar(',');
						ft_putchar(' ');
                    }
				}
				c++;
			}
			c = (b++) + 1;
		}
		b = (a++) + 1;
	}
}
